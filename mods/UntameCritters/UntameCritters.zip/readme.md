Debris (pickupables) which convert into other solid substances will turn into their corresponding debris item when heated to that transition temperature.

This is to prevent the unexpected behavior of items transforming into solid tiles when heated to their transition point, clogging automation and resulting in 50% mass loss when the tile is mined.

This includes algae, slime, and polluted dirt turning to dirt, dirt turning to sand, clay turning to ceramic, coal turning to refined coal, and any other solid-solid transitions.

Liquid and gas transitions are unaffected.

Items in storage bins get dropped onto the floor when they transition, I am not yet smart enough to figure out how to prevent this behavior, though maybe I will revisit later. However, bins no longer get entombed like in vanilla.

Not compatible with DLC yet.
